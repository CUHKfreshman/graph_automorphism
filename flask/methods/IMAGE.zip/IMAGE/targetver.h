//
// Created by sbian on 2019/9/3.
//

#ifndef BIM_TARGETVER_H
#define BIM_TARGETVER_H

// Including SDKDDKVer.h defines the highest available Windows platform.

// If you wish to build your application for a previous Windows platform, include WinSDKVer.h and
// set the _WIN32_WINNT macro to the platform you wish to support before including SDKDDKVer.h.
#ifdef _WIN32
#include <SDKDDKVer.h>
#endif


#endif //BIM_TARGETVER_H
