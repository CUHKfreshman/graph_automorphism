# IMAGE
This project implements the IMAGE-BR and IMAGE algorithms for the following paper:

- Song Bian, Qintian Guo, Sibo Wang, Jeffrey Xu Yu, "Efficient Algorithms for Budgeted Influence Maximization on Massive Social Networks," in PVLDB, 2020.
